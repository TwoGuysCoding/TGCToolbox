
def __version__():
    return "0.1"

def __author__():
    return "Jakub Muszyński"

def __provider__():
    return "TGC"